# Wifite2 + বাংলা Graphical Guide

এই bundle-এ মূল Wifite2 source archive এবং আলাদা বাংলা responsive documentation dashboard রয়েছে।

## কী আছে
- `original/wifite2-master/` — আপলোড করা মূল source archive (অপরিবর্তিত)।
- `docs/index.html` — বাংলা graphical guide; menu, project overview, safe setup checklist, help/keyboard navigation, troubleshooting এবং safety section।
- `.github/workflows/pages.yml` — GitHub Pages-এ guide deploy করার workflow।

## GitHub-এ প্রকাশ
1. ZIP extract করুন।
2. Extract করা bundle-এর সব ফাইল GitHub repository-র root-এ upload/push করুন।
3. Repository → Settings → Pages → Build and deployment → Source: **GitHub Actions** নির্বাচন করুন।
4. Actions tab-এ **Deploy guide to GitHub Pages** workflow সফল হলে Pages URL খুলুন।

এটি **documentation website**, Wifite2 executable বা Android APK builder নয়। মূল Wifite2 হলো Linux-ভিত্তিক command-line wireless auditing project। এই dashboard কোনো Wi-Fi scan, deauthentication, password cracking বা credential attack চালায় না; কেবল project help ও নিরাপদ ব্যবহারের তথ্য দেখায়।

## Local preview
`docs/index.html` ফাইলটি browser-এ খুললেই guide দেখা যাবে। কোনো npm package বা external JavaScript dependency দরকার নেই।

## Source
Upstream project: https://github.com/derv82/wifite2

## ব্যবহার
শুধু নিজের নেটওয়ার্ক বা লিখিত অনুমতি থাকা isolated test lab-এ security testing করুন। মূল project-এর dependency ও platform support জানতে `original/wifite2-master/README.md` পড়ুন।
