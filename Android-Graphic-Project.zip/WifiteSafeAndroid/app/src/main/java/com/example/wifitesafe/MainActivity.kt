package com.example.wifitesafe

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF0A1020)
private val Panel = Color(0xFF151F35)
private val Cyan = Color(0xFF43D9E8)
private val Mint = Color(0xFF65E6B3)
private val Muted = Color(0xFF9BAAC3)

data class WifiItem(val ssid: String, val bssid: String, val level: Int, val frequency: Int, val security: String)

class MainActivity : ComponentActivity() {
    private lateinit var wifi: WifiManager
    private var scanCallback: (() -> Unit)? = null
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) {
            scanCallback?.invoke()
        } else {
            scanCallback = null
        }
    }
    private val documentLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val report = makeReport()
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(report) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        setContent {
            var networks by remember { mutableStateOf(emptyList<WifiItem>()) }
            var status by remember { mutableStateOf("Ready. Scan only networks you own or are authorized to assess.") }
            var tab by remember { mutableIntStateOf(0) }
            var scanning by remember { mutableStateOf(false) }
            val connected = remember { wifi.connectionInfo }
            val ip = remember { try { Formatter.formatIpAddress(wifi.connectionInfo.ipAddress) } catch (_: Exception) { "Unavailable" } }

            fun doScan() {
                val needed = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
                val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isNotEmpty()) {
                    scanCallback = { doScan() }
                    permissionLauncher.launch(missing.toTypedArray())
                    status = "Permission requested. Allow access, then scan again."
                    return
                }
                if (!wifi.isWifiEnabled) {
                    status = "Wi-Fi is turned off. Enable Wi-Fi in Android Settings."
                    scanning = false
                    return
                }
                scanning = true
                status = "Requesting Android Wi-Fi scan…"
                try {
                    wifi.startScan()
                    val found = wifi.scanResults.orEmpty()
                    networks = found.map {
                        WifiItem(
                            ssid = it.SSID.ifBlank { "(Hidden network)" },
                            bssid = it.BSSID ?: "Unavailable",
                            level = WifiManager.calculateSignalLevel(it.level, 5),
                            frequency = it.frequency,
                            security = when {
                                it.capabilities.contains("WEP") -> "WEP (legacy)"
                                it.capabilities.contains("SAE") -> "WPA3"
                                it.capabilities.contains("WPA") -> "WPA/WPA2"
                                it.capabilities.contains("OWE") -> "Enhanced Open"
                                else -> "Open / unknown"
                            }
                        )
                    }.distinctBy { it.bssid }.sortedByDescending { it.level }
                    status = if (networks.isEmpty()) "No scan results yet. Android may throttle scans; try again later." else "Found ${networks.size} nearby access point(s). Passive results only."
                } catch (e: SecurityException) {
                    status = "Permission missing. Grant Nearby Wi-Fi / Location permission in Android Settings."
                } catch (e: Exception) {
                    status = "Scan unavailable: ${e.message ?: "unknown error"}"
                }
                scanning = false
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, secondary = Mint, background = Ink, surface = Panel,
                onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
            )) {
                Scaffold(containerColor = Ink, bottomBar = {
                    NavigationBar(containerColor = Panel) {
                        listOf("Overview", "Networks", "Diagnostics", "About").forEachIndexed { i, label ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Icon(listOf(Icons.Default.Dashboard, Icons.Default.Wifi, Icons.Default.MonitorHeart, Icons.Default.Info)[i], null) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF263B55), unselectedIconColor = Muted, unselectedTextColor = Muted)
                            )
                        }
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).background(Color(0xFF17384A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Shield, null, tint = Cyan, modifier = Modifier.size(27.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("WIFITE SAFE", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 1.5.sp)
                                Text("Wireless diagnostics • passive mode", color = Muted, fontSize = 11.sp)
                            }
                            Surface(color = Color(0xFF153A35), shape = RoundedCornerShape(50)) {
                                Text("SAFE MODE", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                            }
                        }
                        when (tab) {
                            0 -> OverviewScreen(
                                ip,
                                connected.ssid?.removeSurrounding("\"") ?: "Not connected",
                                networks.size, status, scanning,
                                { doScan() }, { tab = 1 }, { tab = 2 }, { tab = 3 },
                                { documentLauncher.launch("wifite-safe-report.txt") }
                            )
                            1 -> NetworkScreen(networks, status, scanning, { doScan() })
                                connected.ssid?.removeSurrounding("\"") ?: "Not connected",
                            else -> AboutScreen()
                        }
                    }
                }
            }
        }
    }

    private fun makeReport(): String {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val info = try { wifi.connectionInfo } catch (_: Exception) { null }
        val ip = try { Formatter.formatIpAddress(wifi.connectionInfo.ipAddress) } catch (_: Exception) { "Unavailable" }
        val results = try { wifi.scanResults.orEmpty() } catch (_: Exception) { emptyList() }
        return buildString {
            appendLine("WIFITE SAFE — Wireless Diagnostics Report")
            appendLine("Generated: $now")
            appendLine("Mode: Passive scan / local device diagnostics only")
            appendLine("Connected SSID: ${info?.ssid ?: "Unavailable"}")
            appendLine("Local IP: $ip")
            appendLine("Visible access points: ${results.size}")
            results.forEach { appendLine("- ${it.SSID.ifBlank { "(Hidden)" }} | ${it.BSSID} | ${it.level} dBm | ${it.frequency} MHz | ${it.capabilities}") }
            appendLine("\nNo password cracking, deauthentication, credential capture, or access attempts are performed.")
        }
    }
}

@Composable
private fun OverviewScreen(
    ip: String, ssid: String, count: Int, status: String, scanning: Boolean,
    scan: () -> Unit, openNetworks: () -> Unit, openDiagnostics: () -> Unit,
    openAbout: () -> Unit, export: () -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Surface(
                color = Color(0xFF123344),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(21.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Color(0xFF1D5362), shape = RoundedCornerShape(13.dp)) {
                            Icon(Icons.Default.Shield, null, tint = Cyan, modifier = Modifier.padding(11.dp).size(27.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("WIRELESS SECURITY CONSOLE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Your Wi-Fi workspace", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(15.dp))
                    Text("Explore and understand your Wi-Fi environment.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 29.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("Passive discovery and device diagnostics in a clean, visual dashboard.", color = Color(0xFFB6D4DF), fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = scan, enabled = !scanning,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Radar, null); Spacer(Modifier.width(9.dp))
                        Text(if (scanning) "SCANNING…" else "START WI-FI SCAN", fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("ACCESS POINTS", count.toString(), Icons.Default.Wifi, Modifier.weight(1f))
                MetricCard("DEVICE IP", if (ip == "0.0.0.0") "—" else ip, Icons.Default.PhoneAndroid, Modifier.weight(1f))
            }
        }
        item {
            Text("TOOLS & FEATURES", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            Text("Choose a task. Each card opens its dedicated page.", color = Muted, fontSize = 11.sp)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TaskCard("Wi-Fi Scanner", "Find nearby access points", Icons.Default.WifiFind, "OPEN SCANNER", openNetworks, Modifier.weight(1f))
                    TaskCard("Network Details", "SSID and device information", Icons.Default.Router, "VIEW DETAILS", openDiagnostics, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TaskCard("Signal & Status", "Review scan and radio status", Icons.Default.NetworkCheck, "VIEW STATUS", openDiagnostics, Modifier.weight(1f))
                    TaskCard("Security Guide", "Understand advertised security", Icons.Default.Security, "LEARN MORE", openAbout, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TaskCard("Export Report", "Save a text diagnostics report", Icons.Default.FileDownload, "EXPORT FILE", export, Modifier.weight(1f))
                    TaskCard("App Information", "Features, limits and safe use", Icons.Default.Info, "OPEN GUIDE", openAbout, Modifier.weight(1f))
                }
            }
        }
        item { InfoCard("CONNECTED NETWORK", ssid, "Current Android Wi-Fi connection", Icons.Default.Router) }
        item { InfoCard("LATEST STATUS", status, "Android scan availability and permission state", Icons.Default.Info) }
        item { SafetyNote() }
    }
}

@Composable
private fun TaskCard(
    title: String, detail: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    action: String, onClick: () -> Unit, modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.heightIn(min = 158.dp),
        color = Panel,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 2.dp
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(
                Modifier.size(40.dp).background(Color(0xFF203B52), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(23.dp)) }
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 10.sp, lineHeight = 14.sp, minLines = 2)
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(action, color = Mint, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.4.sp)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowForward, null, tint = Mint, modifier = Modifier.size(15.dp))
            }
        }
    }
}

@Composable
private fun NetworkScreen(networks: List<WifiItem>, status: String, scanning: Boolean, scan: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Nearby networks", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${networks.size} passive scan result(s)", color = Muted, fontSize = 12.sp)
            }
            Button(onClick = scan, enabled = !scanning, colors = ButtonDefaults.buttonColors(containerColor = Cyan), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Default.Refresh, null); Text(" Scan")
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(status, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        if (networks.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.WifiFind, null, tint = Muted, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("No scan results yet", color = Muted)
                    Text("Tap Scan and grant required permissions.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(networks) { item ->
                    Surface(color = Panel, shape = RoundedCornerShape(15.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Wifi, null, tint = Cyan)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.ssid, fontWeight = FontWeight.SemiBold)
                                    Text(item.security, color = Muted, fontSize = 11.sp)
                                }
                                Text("${item.level}/4", color = Mint, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(progress = { (item.level / 4f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Mint, trackColor = Color(0xFF29364C))
                            Spacer(Modifier.height(7.dp))
                            Text("${item.frequency} MHz  •  ${item.bssid}", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsScreen(enabled: Boolean, ip: String, ssid: String, count: Int, status: String, scan: () -> Unit, export: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Text("Device diagnostics", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { InfoCard("WI-FI RADIO", if (enabled) "Enabled" else "Disabled", "Radio state reported by Android", Icons.Default.Wifi) }
        item { InfoCard("CURRENT SSID", ssid, "Connected network name, if available", Icons.Default.Router) }
        item { InfoCard("LOCAL IP ADDRESS", ip, "Address assigned to this device", Icons.Default.Lan) }
        item { InfoCard("SCAN RESULTS", "$count access point(s)", status, Icons.Default.Radar) }
        item {
            Button(onClick = scan, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("REFRESH DIAGNOSTICS")
            }
        }
        item { OutlinedButton(onClick = export, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("SAVE TEXT REPORT") } }
        item { SafetyNote() }
    }
}

@Composable
private fun AboutScreen() {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Text("About this build", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { InfoCard("PROJECT", "Wifite Safe for Android", "A native graphical companion inspired by the supplied Wifite2 source archive.", Icons.Default.Shield) }
        item { InfoCard("SUPPORTED", "Passive Wi-Fi scan results, signal levels, security capability labels, connected SSID, local IP and report export.", "Features depend on Android version, permissions, hardware and system scan throttling.", Icons.Default.CheckCircle) }
        item { InfoCard("NOT INCLUDED", "No password attacks or network disruption", "No deauthentication, WPS PIN attacks, handshake/PMKID capture, password cracking, evil-twin access points, or credential harvesting.", Icons.Default.Block) }
        item { InfoCard("IMPORTANT", "Android is not Kali Linux", "This APK does not run the original Python Wifite2 engine or its Linux command-line dependencies. Most phones also do not expose monitor mode through the standard Android Wi-Fi API.", Icons.Default.Info) }
        item { SafetyNote() }
    }
}

@Composable
private fun MetricCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Cyan)
            Spacer(Modifier.height(10.dp))
            Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 0.6.sp)
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                Spacer(Modifier.height(3.dp))
                Text(value, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(detail, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SafetyNote() {
    Surface(color = Color(0xFF302A1B), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.GppGood, null, tint = Color(0xFFFFD27A))
            Spacer(Modifier.width(9.dp))
            Text("Use only on networks you own or have explicit permission to assess. Results are passive observations; Android may limit scan frequency and visibility.", color = Color(0xFFFFE5B0), fontSize = 11.sp)
        }
    }
}
